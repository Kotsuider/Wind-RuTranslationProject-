# Script: opmovie.mis

| ID | Ch | Original (JP) | TLE (EN) | TL (RU) |
| :--- | :--- | :--- | :--- | :--- |
| 10 |  |  | Select the cinematic you wish to view.\a | Выберите видеоролик для просмотра.\a |
| SELECT_1 |  |  | Wind | Wind |
| SELECT_2 |  |  | Dream | Dream |
| SELECT_3 |  |  | TSU-BA-SA | TSU-BA-SA |
| 20 |  |  | Select the cinematic you wish to view.\a | Выберите видеоролик для просмотра.\a |
| SELECT_1 |  |  | Wind | Wind |
| SELECT_2 |  |  | Dream | Dream |
| 30 |  |  | Select the cinematic you wish to view.\a | Выберите видеоролик для просмотра.\a |
| SELECT_1 |  |  | Wind | Wind |
| SELECT_2 |  |  | TSU-BA-SA | TSU-BA-SA |
