# Script: opmovie.mis

| ID | Ch | Original (JP) | TLE (EN) | TL (RU) |
| :--- | :--- | :--- | :--- | :--- |
| 10 |  |  | Select the cinematic you wish to view.\a | Выберите видеоролик для просмотра.\a |
| SELECT_1 |  |  | Wind | Ветер |
| SELECT_2 |  |  | Dream | Мечта |
| SELECT_3 |  |  | TSU-BA-SA | Крылья |
| 20 |  |  | Select the cinematic you wish to view.\a | Выберите видеоролик для просмотра.\a |
| SELECT_1 |  |  | Wind | Ветер |
| SELECT_2 |  |  | Dream | Мечта |
| 30 |  |  | Select the cinematic you wish to view.\a | Выберите видеоролик для просмотра.\a |
| SELECT_1 |  |  | Wind | Ветер |
| SELECT_2 |  |  | TSU-BA-SA | Крылья |
